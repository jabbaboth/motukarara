# Motukarara Crew Tracker

Complete Next.js application with all 264 jobs from your Excel file.

## ✅ What's Included

- **All 264 Jobs**: Every row from your Excel spreadsheet
- **4 Crews**: Jade (79 jobs), Ryan (80 jobs), Jamie (60 jobs), Hedge & Shelter Trimmer (45 jobs)
- **24 Working Days**: Feb 9 - Mar 12, 2026
- **Real-time Tracking**: Mark jobs complete with localStorage persistence
- **Mobile Responsive**: Works on phones, tablets, and desktops
- **Statistics Dashboard**: Live progress tracking
- **Crew Management**: Filter by date and crew

## 🚀 Quick Start

### Option 1: Run Locally (No Airtable Required)

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open browser
http://localhost:3000
```

The app works immediately with all 264 jobs embedded!

### Option 2: Connect to Airtable (For Production)

1. **Create Airtable Base**
   - Go to airtable.com
   - Create new base
   - Create "Jobs" table with fields from `docs/requirements.md`

2. **Import Data**
   ```bash
   # Copy environment variables
   cp .env.local.example .env.local
   
   # Edit .env.local with your Airtable credentials
   nano .env.local
   
   # Import all 264 jobs
   node scripts/import-all-jobs.js
   ```

3. **Run App**
   ```bash
   npm run dev
   ```

## 📁 Project Structure

```
motukarara-app/
├── app/
│   ├── page.js              # Main application (all 264 jobs embedded)
│   ├── layout.js            # Root layout
│   └── globals.css          # Tailwind styles
├── components/
│   ├── StatCard.jsx         # Statistics card component
│   └── JobCard.jsx          # Job display card
├── lib/
│   └── airtable.js          # Airtable connection (optional)
├── scripts/
│   └── import-all-jobs.js   # Import script for Airtable
├── all_jobs_data.json       # All 264 jobs data
├── package.json             # Dependencies
└── README.md                # This file
```

## 📊 Features

### Dashboard View
- Total jobs: 264
- Total spans tracking
- Total hours: 498.5
- Completion percentages

### Calendar View
- Filter by date (24 working days)
- Filter by crew (4 crews)
- Daily crew statistics
- Job completion tracking

### Crew Summary
- Individual crew performance
- Progress bars
- Spans and hours tracking
- Completion rates

## 🎨 Customization

### Crew Colors
Edit `tailwind.config.js`:
```javascript
colors: {
  'crew-jade': '#2E86AB',    // Teal
  'crew-ryan': '#A23B72',    // Purple
  'crew-jamie': '#F18F01',   // Orange
}
```

### Feeder Colors
Edit in `components/JobCard.jsx`:
```javascript
const feederColors = {
  'MOTU 111': 'bg-[#ffa07a20]',  // Light orange
  'MOTU 112': 'bg-[#ff6b6b20]',  // Light red
  'MOTU 113': 'bg-[#45b7d120]',  // Light blue
  'MOTU 114': 'bg-[#4ecdc420]',  // Light teal
};
```

## 📱 Mobile Optimization

- Touch-friendly tap targets (minimum 44px)
- Responsive grid layouts
- No zoom on input focus
- Optimized for field use

## 🔧 Using with Claude Code

### Enhance with Claude Code

1. **Open in Claude Code**
   ```bash
   code .
   # Or use Claude Code directly
   ```

2. **Ask Claude Code to:**
   - "Add photo upload for completed jobs"
   - "Add offline mode with service worker"
   - "Add GPS location tracking"
   - "Create export to Excel feature"
   - "Add user authentication"
   - "Create weekly report emails"

3. **Example Prompts**:
   ```
   "Add a feature to export the current view to PDF"
   "Create a PWA manifest for mobile installation"
   "Add dark mode support"
   "Implement real-time sync with Airtable"
   "Add a search function to find jobs by address"
   ```

## 📈 Data Structure

Each job has:
```javascript
{
  job_id: 1,
  date: "2026-02-09",
  crew_name: "Jade",
  full_address: "67 Ahuriri Rd",
  address_number: "316",
  feeder: "MOTU 112",
  job_duration_hours: 4.0,
  spans: 1.0,
  start_time: "08:00",
  end_time: "12:00",
  status: "Pending",
  additional_crews_required: "Hedge & Shelter Trimmer"
}
```

## 🚢 Deployment

### Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Production deployment
vercel --prod
```

### Environment Variables
Add to Vercel dashboard:
- `AIRTABLE_API_KEY` (if using Airtable)
- `AIRTABLE_BASE_ID` (if using Airtable)
- `NEXT_PUBLIC_AIRTABLE_BASE_ID` (if using Airtable)

## 📚 Documentation

Full documentation available in `/docs`:
- `QUICK_START.md` - Fast setup guide
- `ACTION_PLAN.md` - Complete project roadmap
- `developer_prompt.md` - Technical specifications
- `requirements.md` - Full requirements

## 🔑 Key Files

- `all_jobs_data.json` - All 264 jobs (source of truth)
- `app/page.js` - Main application logic
- `components/JobCard.jsx` - Job display component
- `scripts/import-all-jobs.js` - Airtable import

## 🐛 Troubleshooting

**Jobs not showing?**
- Check `all_jobs_data.json` exists
- Verify import in `app/page.js`

**Styles not working?**
- Run `npm install`
- Check Tailwind config

**Can't connect to Airtable?**
- Verify `.env.local` credentials
- Check Airtable API key
- Ensure Base ID is correct

## 📞 Support

- Create GitHub issue
- Check documentation in `/docs`
- Review `PROJECT_MASTER.md` for complete context

## ✨ Next Steps

1. Run `npm install` and `npm run dev`
2. Test the application locally
3. Deploy to Vercel
4. Share URL with your team
5. Use Claude Code to add more features!

---

**Built with:** Next.js 14, React 18, Tailwind CSS  
**Data:** All 264 jobs from Motukarara_Delivery_Standardised_With_Addresses.xlsx  
**Ready to deploy!** 🚀
