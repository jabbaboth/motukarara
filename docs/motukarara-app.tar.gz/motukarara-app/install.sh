#!/bin/bash

# Motukarara Crew Tracker - Quick Install Script

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🚀 MOTUKARARA CREW TRACKER - QUICK INSTALL"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed"
    echo ""
    echo "Please install Node.js 18+ from: https://nodejs.org"
    exit 1
fi

NODE_VERSION=$(node --version)
echo "✅ Node.js installed: $NODE_VERSION"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully!"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✨ INSTALLATION COMPLETE!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "🎯 Quick Start:"
echo ""
echo "   1. Run development server:"
echo "      npm run dev"
echo ""
echo "   2. Open browser:"
echo "      http://localhost:3000"
echo ""
echo "   3. Start tracking your 264 jobs!"
echo ""
echo "📚 Next Steps:"
echo ""
echo "   - Read README.md for full documentation"
echo "   - Read CLAUDE_CODE_GUIDE.md to add more features"
echo "   - Deploy to Vercel when ready: vercel"
echo ""
echo "💡 Optional - Connect to Airtable:"
echo ""
echo "   1. cp .env.local.example .env.local"
echo "   2. Edit .env.local with your Airtable credentials"
echo "   3. node scripts/import-all-jobs.js"
echo ""
echo "🚀 Happy tracking!"
echo ""
