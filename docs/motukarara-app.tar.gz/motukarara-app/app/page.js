'use client';

import { useState, useEffect, useMemo } from 'react';
import StatCard from '../components/StatCard';
import JobCard from '../components/JobCard';

// Import all 264 jobs
import allJobsData from '../all_jobs_data.json';

export default function Home() {
  const [completedJobs, setCompletedJobs] = useState({});
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedCrew, setSelectedCrew] = useState('All');
  const [viewMode, setViewMode] = useState('calendar'); // calendar or summary

  // Load completed jobs from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('completed_jobs');
    if (stored) {
      try {
        setCompletedJobs(JSON.parse(stored));
      } catch (e) {
        console.error('Error loading completed jobs:', e);
      }
    }

    // Set default date to first date with jobs
    if (allJobsData.length > 0) {
      setSelectedDate(allJobsData[0].date);
    }
  }, []);

  // Save completed jobs to localStorage
  const saveCompletedJobs = (newCompleted) => {
    try {
      localStorage.setItem('completed_jobs', JSON.stringify(newCompleted));
    } catch (e) {
      console.error('Error saving completed jobs:', e);
    }
  };

  // Toggle job completion
  const toggleJobCompletion = (jobId) => {
    const newCompleted = { ...completedJobs };
    if (newCompleted[jobId]) {
      delete newCompleted[jobId];
    } else {
      newCompleted[jobId] = new Date().toISOString();
    }
    setCompletedJobs(newCompleted);
    saveCompletedJobs(newCompleted);
  };

  // Get unique dates and crews
  const dates = useMemo(() => {
    return [...new Set(allJobsData.map(j => j.date))].sort();
  }, []);

  const crews = useMemo(() => {
    return ['All', ...new Set(allJobsData.map(j => j.crew_name))].sort();
  }, []);

  // Calculate overall statistics
  const stats = useMemo(() => {
    const total = allJobsData.length;
    const completed = Object.keys(completedJobs).length;
    const totalSpans = allJobsData.reduce((sum, j) => sum + (j.spans || 0), 0);
    const completedSpans = allJobsData
      .filter(j => completedJobs[j.job_id])
      .reduce((sum, j) => sum + (j.spans || 0), 0);
    const totalHours = allJobsData.reduce((sum, j) => sum + (j.job_duration_hours || 0), 0);

    return {
      totalJobs: total,
      completedJobs: completed,
      remainingJobs: total - completed,
      completionPercent: total > 0 ? ((completed / total) * 100).toFixed(1) : 0,
      totalSpans,
      completedSpans,
      remainingSpans: totalSpans - completedSpans,
      spansPercent: totalSpans > 0 ? ((completedSpans / totalSpans) * 100).toFixed(1) : 0,
      totalHours: totalHours.toFixed(1)
    };
  }, [completedJobs]);

  // Calculate daily stats for selected date
  const dailyStats = useMemo(() => {
    const dayJobs = allJobsData.filter(j => 
      j.date === selectedDate && 
      (selectedCrew === 'All' || j.crew_name === selectedCrew)
    );

    const crewStats = {};
    crews.filter(c => c !== 'All').forEach(crew => {
      const crewJobs = dayJobs.filter(j => j.crew_name === crew);
      const completed = crewJobs.filter(j => completedJobs[j.job_id]);
      
      crewStats[crew] = {
        totalJobs: crewJobs.length,
        completedJobs: completed.length,
        targetSpans: crewJobs.reduce((sum, j) => sum + (j.spans || 0), 0),
        completedSpans: completed.reduce((sum, j) => sum + (j.spans || 0), 0),
        targetHours: crewJobs.reduce((sum, j) => sum + (j.job_duration_hours || 0), 0)
      };
    });

    return crewStats;
  }, [selectedDate, selectedCrew, completedJobs, crews]);

  // Filter jobs for display
  const filteredJobs = useMemo(() => {
    return allJobsData.filter(j => 
      j.date === selectedDate && 
      (selectedCrew === 'All' || j.crew_name === selectedCrew)
    );
  }, [selectedDate, selectedCrew]);

  // Crew color mapping
  const crewColorClass = {
    'Jade': 'crew-jade',
    'Ryan': 'crew-ryan',
    'Jamie': 'crew-jamie'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold">Motukarara Powerline Contract</h1>
          <p className="text-blue-100 mt-1">Crew Tracking & Progress Management System</p>
          <p className="text-blue-200 text-sm mt-2">All 264 Jobs | Feb 9 - Mar 12, 2026</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Navigation */}
        <div className="bg-white rounded-lg shadow mb-6 p-2 flex gap-2">
          <button
            onClick={() => setViewMode('calendar')}
            className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
              viewMode === 'calendar' 
                ? 'bg-blue-600 text-white' 
                : 'hover:bg-gray-100'
            }`}
          >
            📅 Daily View
          </button>
          <button
            onClick={() => setViewMode('summary')}
            className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
              viewMode === 'summary' 
                ? 'bg-blue-600 text-white' 
                : 'hover:bg-gray-100'
            }`}
          >
            📊 Crew Summary
          </button>
        </div>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <StatCard 
            title="Total Jobs"
            value={stats.totalJobs}
            subtext={`${stats.completedJobs} completed • ${stats.remainingJobs} remaining`}
            progress={parseFloat(stats.completionPercent)}
            color="green"
          />
          <StatCard 
            title="Total Spans"
            value={stats.totalSpans.toFixed(1)}
            subtext={`${stats.completedSpans.toFixed(1)} completed • ${stats.remainingSpans.toFixed(1)} remaining`}
            progress={parseFloat(stats.spansPercent)}
            color="blue"
          />
          <StatCard 
            title="Total Hours"
            value={stats.totalHours}
            subtext={`Across ${crews.length - 1} crews`}
          />
          <StatCard 
            title="Project Timeline"
            value={`${dates.length} days`}
            subtext="Feb 9 - Mar 12, 2026"
          />
        </div>

        {/* Calendar View */}
        {viewMode === 'calendar' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4">Daily Schedule</h2>

            {/* Filters */}
            <div className="mb-6 flex gap-4 flex-wrap">
              <select 
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-4 py-2 border rounded-lg"
              >
                {dates.map(date => (
                  <option key={date} value={date}>
                    {new Date(date + 'T00:00:00').toLocaleDateString('en-US', { 
                      weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'
                    })}
                  </option>
                ))}
              </select>

              <select 
                value={selectedCrew}
                onChange={(e) => setSelectedCrew(e.target.value)}
                className="px-4 py-2 border rounded-lg"
              >
                {crews.map(crew => (
                  <option key={crew} value={crew}>
                    {crew === 'All' ? 'All Crews' : crew}
                  </option>
                ))}
              </select>
            </div>

            {/* Daily Crew Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {Object.entries(dailyStats).map(([crew, stats]) => {
                if (selectedCrew !== 'All' && selectedCrew !== crew) return null;
                if (stats.totalJobs === 0) return null;

                return (
                  <div key={crew} className={`bg-gradient-to-br from-white to-gray-50 rounded-lg p-4 border-l-4 border-${crewColorClass[crew] || 'gray-500'}`}>
                    <div className="font-bold text-lg mb-2">{crew}</div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <div className="text-gray-600">Jobs</div>
                        <div className="font-semibold">{stats.completedJobs}/{stats.totalJobs}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Spans</div>
                        <div className="font-semibold text-blue-600">
                          {stats.completedSpans.toFixed(1)}/{stats.targetSpans.toFixed(1)}
                        </div>
                      </div>
                      <div>
                        <div className="text-gray-600">Hours</div>
                        <div className="font-semibold">{stats.targetHours.toFixed(1)}h</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Progress</div>
                        <div className="font-semibold text-green-600">
                          {stats.totalJobs > 0 ? ((stats.completedJobs / stats.totalJobs) * 100).toFixed(0) : 0}%
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Job List */}
            <div className="space-y-2">
              <h3 className="text-xl font-semibold mb-3">
                {filteredJobs.length} Jobs for {new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-US', { 
                  weekday: 'long', month: 'long', day: 'numeric' 
                })}
              </h3>
              
              {filteredJobs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No jobs scheduled for this date/crew
                </div>
              ) : (
                filteredJobs.map(job => (
                  <JobCard 
                    key={job.job_id}
                    job={job}
                    isCompleted={!!completedJobs[job.job_id]}
                    onToggle={() => toggleJobCompletion(job.job_id)}
                  />
                ))
              )}
            </div>
          </div>
        )}

        {/* Crew Summary View */}
        {viewMode === 'summary' && (
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4">Crew Performance Summary</h2>

            {crews.filter(c => c !== 'All').map(crew => {
              const crewJobs = allJobsData.filter(j => j.crew_name === crew);
              const completed = crewJobs.filter(j => completedJobs[j.job_id]);
              const completedSpans = completed.reduce((sum, j) => sum + (j.spans || 0), 0);
              const totalSpans = crewJobs.reduce((sum, j) => sum + (j.spans || 0), 0);
              const totalHours = crewJobs.reduce((sum, j) => sum + (j.job_duration_hours || 0), 0);

              return (
                <div key={crew} className={`mb-6 p-6 rounded-lg border-2 border-l-4 border-${crewColorClass[crew] || 'gray-500'}`}>
                  <h3 className="text-xl font-bold mb-4">{crew}</h3>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-600">Target Jobs</div>
                      <div className="text-2xl font-bold">{crewJobs.length}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Completed</div>
                      <div className="text-2xl font-bold text-green-600">{completed.length}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Total Spans</div>
                      <div className="text-2xl font-bold text-blue-600">{totalSpans.toFixed(1)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Total Hours</div>
                      <div className="text-2xl font-bold text-purple-600">{totalHours.toFixed(1)}h</div>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Overall Progress</span>
                      <span className="font-semibold">
                        {crewJobs.length > 0 ? ((completed.length / crewJobs.length) * 100).toFixed(1) : 0}%
                      </span>
                    </div>
                    <div className="bg-gray-200 rounded-full h-3">
                      <div 
                        className="bg-green-500 h-3 rounded-full transition-all"
                        style={{ width: `${crewJobs.length > 0 ? (completed.length / crewJobs.length) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-gray-800 text-white mt-12 py-6">
        <div className="container mx-auto px-4 text-center text-sm">
          <p>Motukarara Powerline Vegetation Contract Tracking System</p>
          <p className="text-gray-400 mt-1">264 Total Jobs | All Crews Tracked</p>
        </div>
      </div>
    </div>
  );
}
