import './globals.css'

export const metadata = {
  title: 'Motukarara Crew Tracker',
  description: 'Crew tracking and progress management for Motukarara Powerline vegetation contract',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
