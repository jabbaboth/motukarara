/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'crew-jade': '#2E86AB',
        'crew-ryan': '#A23B72',
        'crew-jamie': '#F18F01',
        'feeder-111': '#ffa07a20',
        'feeder-112': '#ff6b6b20',
        'feeder-113': '#45b7d120',
        'feeder-114': '#4ecdc420',
      },
    },
  },
  plugins: [],
}
