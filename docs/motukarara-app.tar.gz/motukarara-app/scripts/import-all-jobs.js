#!/usr/bin/env node

/**
 * Complete Airtable Import Script
 * Imports ALL 264 jobs from Excel with proper crew assignments
 */

const Airtable = require('airtable');
const fs = require('fs');
const path = require('path');

// Load environment variables
require('dotenv').config({ path: path.join(__dirname, '../.env.local') });

// Validate environment variables
if (!process.env.AIRTABLE_API_KEY || !process.env.AIRTABLE_BASE_ID) {
  console.error('❌ Error: Missing AIRTABLE_API_KEY or AIRTABLE_BASE_ID');
  console.error('Please create .env.local file with your Airtable credentials');
  process.exit(1);
}

// Configure Airtable
const base = new Airtable({
  apiKey: process.env.AIRTABLE_API_KEY
}).base(process.env.AIRTABLE_BASE_ID);

const jobsTable = base('Jobs');

// Load the processed job data
const jobsData = JSON.parse(fs.readFileSync(path.join(__dirname, '../all_jobs_data.json'), 'utf8'));

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('  MOTUKARARA CREW MANAGEMENT - AIRTABLE IMPORT');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('');
console.log(`📊 Total jobs to import: ${jobsData.length}`);
console.log('');

// Show crew breakdown
const crewBreakdown = {};
jobsData.forEach(job => {
  crewBreakdown[job.crew_name] = (crewBreakdown[job.crew_name] || 0) + 1;
});

console.log('👥 Crew breakdown:');
Object.entries(crewBreakdown).forEach(([crew, count]) => {
  console.log(`   ${crew}: ${count} jobs`);
});
console.log('');

// Ask for confirmation
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

async function importJobs() {
  const answer = await new Promise(resolve => {
    readline.question(`Import all ${jobsData.length} jobs to Airtable? (yes/no): `, resolve);
  });
  readline.close();

  if (answer.toLowerCase() !== 'yes') {
    console.log('❌ Import cancelled');
    process.exit(0);
  }

  console.log('');
  console.log('📤 Starting import...');
  console.log('');

  const BATCH_SIZE = 10; // Airtable allows max 10 records per batch
  let successCount = 0;
  let errorCount = 0;

  for (let i = 0; i < jobsData.length; i += BATCH_SIZE) {
    const batch = jobsData.slice(i, i + BATCH_SIZE);

    // Transform to Airtable format
    const records = batch.map(job => ({
      fields: {
        'date': job.date,
        'crew_name': job.crew_name,
        'full_address': job.full_address,
        'address_number': job.address_number,
        'feeder': job.feeder,
        'job_duration_hours': job.job_duration_hours,
        'spans': job.spans,
        'start_time': job.start_time,
        'end_time': job.end_time,
        'status': 'Pending',
        'additional_crews_required': job.additional_crews_required
      }
    }));

    try {
      await jobsTable.create(records);
      successCount += records.length;
      
      // Progress indicator
      const progress = Math.floor((successCount / jobsData.length) * 100);
      console.log(`  ✓ Imported ${successCount}/${jobsData.length} (${progress}%)`);

      // Rate limiting - wait 1 second between batches to respect API limits
      if (i + BATCH_SIZE < jobsData.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error(`  ✗ Error in batch starting at job ${i + 1}:`, error.message);
      errorCount += records.length;
    }
  }

  console.log('');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  IMPORT COMPLETE');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('');
  console.log(`✅ Successfully imported: ${successCount} jobs`);
  if (errorCount > 0) {
    console.log(`❌ Failed: ${errorCount} jobs`);
  }
  console.log('');
  console.log('📊 Summary:');
  console.log(`   Total jobs: ${jobsData.length}`);
  console.log(`   Date range: ${jobsData[0].date} to ${jobsData[jobsData.length - 1].date}`);
  console.log(`   Total hours: ${jobsData.reduce((sum, j) => sum + j.job_duration_hours, 0).toFixed(1)}`);
  console.log(`   Crews: ${Object.keys(crewBreakdown).length}`);
  console.log('');
  console.log('✨ Your Airtable base is now ready!');
  console.log('');
  console.log('Next steps:');
  console.log('  1. Go to airtable.com and verify your data');
  console.log('  2. Run: npm run dev');
  console.log('  3. Open: http://localhost:3000');
  console.log('');
}

// Run the import
importJobs().catch(error => {
  console.error('');
  console.error('💥 Fatal error:', error);
  process.exit(1);
});
