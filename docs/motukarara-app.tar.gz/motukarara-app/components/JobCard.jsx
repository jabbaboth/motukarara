export default function JobCard({ job, onToggle, isCompleted }) {
  const crewColors = {
    'Jade': 'border-l-4 border-crew-jade',
    'Ryan': 'border-l-4 border-crew-ryan',
    'Jamie': 'border-l-4 border-crew-jamie',
    'Hedge & Shelter Trimmer': 'border-l-4 border-gray-500'
  };

  const feederColors = {
    'MOTU 111': 'bg-[#ffa07a20]',
    'MOTU 112': 'bg-[#ff6b6b20]',
    'MOTU 113': 'bg-[#45b7d120]',
    'MOTU 114': 'bg-[#4ecdc420]'
  };

  return (
    <div 
      onClick={onToggle}
      className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
        crewColors[job.crew_name] || 'border-l-4 border-gray-400'
      } ${feederColors[job.feeder] || ''} ${
        isCompleted ? 'bg-green-50 opacity-75' : 'bg-white'
      }`}
    >
      <div className="flex items-start gap-4">
        <input 
          type="checkbox"
          checked={isCompleted}
          onChange={() => {}}
          className="w-5 h-5 mt-1 cursor-pointer"
        />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <div className="font-semibold text-lg">
                {job.full_address}
              </div>
              <div className="text-sm text-gray-600 mt-1">
                Job #{job.job_id} • {job.crew_name} • {job.feeder}
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">
                {job.spans?.toFixed(1) || '1.0'}
              </div>
              <div className="text-xs text-gray-500">spans</div>
            </div>
          </div>
          <div className="mt-2 flex gap-4 text-sm flex-wrap">
            <span className="text-gray-600">⏱ {job.job_duration_hours}h</span>
            {job.start_time && (
              <span className="text-gray-600">🕐 {job.start_time} - {job.end_time}</span>
            )}
            {isCompleted && (
              <span className="text-green-600 font-semibold">✓ Completed</span>
            )}
            {job.additional_crews_required && (
              <span className="text-orange-600 text-xs">
                + {job.additional_crews_required}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
