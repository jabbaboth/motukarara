export default function StatCard({ title, value, subtext, progress, color = 'green' }) {
  const colorClasses = {
    green: 'bg-green-500',
    blue: 'bg-blue-500',
    purple: 'bg-purple-500',
    gray: 'bg-gray-500'
  };

  const textColorClasses = {
    green: 'text-green-600',
    blue: 'text-blue-600',
    purple: 'text-purple-600',
    gray: 'text-gray-600'
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="text-sm text-gray-600 mb-1">{title}</div>
      <div className="text-3xl font-bold text-gray-900">{value}</div>
      {subtext && (
        <div className="text-xs text-gray-500 mt-2">{subtext}</div>
      )}
      {progress !== undefined && (
        <>
          <div className="mt-3 bg-gray-200 rounded-full h-2">
            <div 
              className={`${colorClasses[color]} h-2 rounded-full transition-all duration-500`}
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
            />
          </div>
          <div className={`text-sm font-semibold mt-2 ${textColorClasses[color]}`}>
            {progress}% Complete
          </div>
        </>
      )}
    </div>
  );
}
